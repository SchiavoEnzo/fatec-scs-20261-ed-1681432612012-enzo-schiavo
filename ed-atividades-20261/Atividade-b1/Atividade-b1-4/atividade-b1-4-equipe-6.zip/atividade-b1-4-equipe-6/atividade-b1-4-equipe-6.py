operador = 0
class Pilha:

    def __init__ (self):
        self.itens = []
        self.next = 0

    def add(self, number):
        if len(self.itens) < 4:
            self.itens.append(number)
        else:
            for i in range(4):
                if i < 3:
                    self.itens[i] = self.itens[i + 1]
                else:
                    self.itens[3] = number
        self.list()

    def operate (self, option):
        res = 0

        if operador > 0:
            ##for i in operador:
            if option == "+":
                self.itens[-2] += self.itens[-1]
            elif option == "-":
                self.itens[-2] -= self.itens[-1]
            elif option == "/":
                self.itens[-2] /= self.itens[-1]
            elif option == "*":
                self.itens[-2] *= self.itens[-1]
            else:
                return print("Operador Inválido.")
            self.itens.pop()
        elif len(self.itens) > 1:
            if option == "*":
                res = 1
            elif option == "/":
                res = self.itens[-1] * self.itens[-1]
            for i in self.itens:
                if option == "+":
                    res += i
                elif option == "-":
                    res -= i
                elif option == "/":
                    res /= i
                elif option == "*":
                    res = i * res
                else:
                    return print("Operador Inválido.")
            self.itens[-2] = res
            self.nextO = self.itens.index(self.itens[-2], -3)
            print(self.nextO)
            self.itens.pop()
        else:
            self.itens[-1] = self.itens[-1] + self.itens[-2]
        print(f"Resultado {self.itens[-1]}")
        return True



    def list(self):
        j = 0
        if len(self.itens) == 0 :
            print("Lista vazia")
            return

        print("\n")
        try :
            print(f"X {self.itens[0]}")
        except IndexError:
            print(f"X 0")
        try :
            print(f"Y {self.itens[1]}")
        except IndexError:
            print(f"Y 0")
        try :
            print(f"Z {self.itens[2]}")
        except IndexError:
            print(f"Z 0")
        try :
            print(f"T {self.itens[3]}")
        except IndexError:
            print(f"T 0")

def is_number(s):
    try:
        float(s)
        return True
    except error:
        return False

pilha = Pilha()
while True:

    option = input("Input: \n")
    if option == "listar":
        pilha.list()
    elif option == "cls":
        pilha.itens.clear()
        operador = 0
        print("Limpo")
    elif option == "break":
        break
    else:
        operation = option.split()
        expressionN = []
        expressionS = ""
        result = ""
        op = False
        for n in operation:
            try:
                pilha.add(float(n))
                expressionN.append(n)

            except ValueError:
                expressionS = n
                for i in expressionN:
                    if expressionN[-1] == i:
                        if result.endswith(f")"):
                            result += f" {n}"
                        result += f" {i} "
                    elif expressionN[-1] != i:
                        result += f" {i} "
                        result += f"{n}"
                result = f"({result})"
                operador = len(expressionN)
                expressionN.clear()
                op = pilha.operate(n)
                pilha.list()

        if op == True:
            print(f"A expressão algébrica é: {result}")
